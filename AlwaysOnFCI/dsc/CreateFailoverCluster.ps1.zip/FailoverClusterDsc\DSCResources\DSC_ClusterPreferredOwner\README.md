# Description

Configures preferred owners of a cluster group and cluster resources in a failover
cluster.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
