# Description

Configures quorum in a cluster. For information on how to choose the correct
quorum type, please see the article
[Understanding Quorum Configurations in a Failover Cluster](https://technet.microsoft.com/en-us/library/cc731739(v=ws.11).aspx).

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
