# Description

Ensures that a node waits for a remote cluster is created.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
