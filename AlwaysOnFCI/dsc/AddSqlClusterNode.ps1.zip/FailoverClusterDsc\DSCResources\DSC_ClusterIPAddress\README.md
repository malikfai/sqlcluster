# Description

Used to configure IP addresses for a failover cluster. Ensures that a specific IP address is either present or absent from the cluster.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
